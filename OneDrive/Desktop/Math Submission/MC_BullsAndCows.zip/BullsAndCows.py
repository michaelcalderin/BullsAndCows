import random
import math
import matplotlib.pyplot as plt

# Game class for Bulls and Cows
class Game:

    def __init__(self, passwordLength=4):
        # Sets the password length (cannot be greater than 10 because unique digits would not be possible, cannot be less than 1 because no password would exist)
        if passwordLength <= 10 and passwordLength >= 1:
            self.passwordLength = passwordLength
        else:
            # Defaults to 4 for invalid input
            self.passwordLength = 4


        # Defines the different error codes related to the user's input
        self.validationErrors = {-1: 'SUCCESSFUL', 0: f'WRONG LENGTH! INPUT MUST BE {self.passwordLength} DIGITS LONG!', 1: 'NON-DIGIT FOUND! INPUT CAN ONLY CONTAIN DIGITS 0-9!', 2: 'ALL DIGITS MUST BE DIFFERENT!'}
        
        # Begins the game
        self.initialize()
        return
    
    def initialize(self):
        # Initalizing variables
        self.password = self.generatePassword()
        self.bulls = 0
        self.cows = 0

        # Header for design
        print("-----------STARTING BULLS AND COWS-----------")

        continueGame = True

        while continueGame:

            # Asking for guess repeatedly until the user provides proper input
            validEntry = False

            while(not validEntry):
                self.guess = input(f'Enter your guess for the {self.passwordLength} digit password: ')
                validationCode = self.validateEntry(self.guess)

                if validationCode != -1:
                    print(self.validationErrors[validationCode])
                else:
                    validEntry = True
                
            # Display the user's guess with the number of bulls and cows
            bulls = self.numBulls(self.guess, self.password)
            cows = self.numCows(self.guess, self.password)
            entropy = self.currentEntropy()
            print(f'You guessed: {self.guess}')
            print(f'Bulls: {bulls}')
            print(f'Cows: {cows}')
            print(f'Entropy: {entropy:.2f}')
            print()

            if bulls == self.passwordLength:
                print('You cracked the code!')
                print(f'The password was: {self.password}')
                continueGame = False

        # Footer for design
        print("-----------ENDING BULLS AND COWS-----------")

        return
    
    def generatePassword(self):
        # Randomly generates an integer password
        password = ""
        digitsAvailable = [digit for digit in range(0, 10)]

        for _ in range(self.passwordLength):
            index = random.randint(0, len(digitsAvailable)-1)
            password += str(digitsAvailable[index])
            digitsAvailable.pop(index)

        # Pads password to be desired password length (left padding)
        if len(password) < self.passwordLength:
            padding = '0' * (self.passwordLength - len(password))
            password = padding + password

        return password

    def currentEntropy(self):
        # Calculate number of codes that match the number of bulls and cows in the guess
        availableDigits = {digit for digit in range(0, 10)}
        code = ""
        currentPossibilities = self.numPossiblePasswords(availableDigits, code)

        # Out of the possible passwords, find the probability that a given code is the password
        # Note: other codes would have probability 0 of being the password
        probability = 1/currentPossibilities

        # Calculate entropy based on probability
        entropy = -1 * currentPossibilities * (probability * math.log2(probability))
        
        return abs(entropy)

    def numPossiblePasswords(self, availableDigits, code):

        # Base case
        if len(code) == self.passwordLength:
            # If cows/bulls of guess compared to password is the same as the cows/bulls of guess compared to this code then it is a possible password (return 1)
            if self.numBulls(self.guess, self.password) == self.numBulls(self.guess, code) and self.numCows(self.guess, self.password) == self.numCows(self.guess, code):
                return 1
            else:
                return 0

        # Recursively explore every possible code and add up the number of possible passwords based on cows/bulls
        numMatches = 0

        if len(code) < self.passwordLength:
            for digit in availableDigits:
                code += str(digit)
                updatedDigits = availableDigits.copy()
                updatedDigits.remove(digit)
                numMatches += self.numPossiblePasswords(updatedDigits, code)
                code = code[:-1]

        return numMatches
    
    def numBulls(self, guess, password):
        # Counts the number of digits in the guess that match the password
        count = 0

        for i in range(len(guess)):
            if guess[i] == password[i]:
                count += 1

        return count

    def numCows(self, guess, password):
        # Count the frequency of each digit in the guess
        guessDigitFrequency = {}
        for digit in guess:
            if digit not in guessDigitFrequency:
                guessDigitFrequency[digit] = 1
            else:
                guessDigitFrequency[digit] += 1

        # Count the frequency of each digit in the password
        passwordDigitFrequency = {}
        for digit in password:
            if digit not in passwordDigitFrequency:
                passwordDigitFrequency[digit] = 1
            else:
                passwordDigitFrequency[digit] += 1

        # Count the number of digits in guess that are also in password
        count = 0

        for digit in guessDigitFrequency:
            if digit in passwordDigitFrequency:
                count += min(guessDigitFrequency[digit], passwordDigitFrequency[digit])

        # Count currently includes bulls so remove them
        count -= self.numBulls(guess, password)

        return count
    
    def validateEntry(self, entry):
        # Returns an error code of 0 if entry is too long or too short
        if len(entry) != self.passwordLength:
            return 0
        
        # Returns an error code of 1 if entry has non-digit characters
        for character in entry:
            if not character.isdigit():
                return 1
            
        # Returns an error code of 2 if entry has repeated digits
        counts = {}

        for digit in entry:
            if digit not in counts:
                counts[digit] = 1
            else:
                counts[digit] += 1

        for digit in counts:
            if counts[digit] > 1:
                return 2
        
        # Returns -1 to signify the entry is valid (no errors)
        return -1
    

def main():

    # Welcome message and instructions
    print("oooooooooooooooooooooooooooooooooooooooooooooo")
    print("Welcome to Bulls and Cows!\n")
    print("There is a secret 4-digit password that you have to guess. For example, it could be 1234.")
    print("When guessing, you cannot repeat digits. For example, 1233 is not a valid guess because 3 occurs more than once.\n")
    print("Use bulls, cows, and entropy to guide you:")
    print("1. Bulls represent digits in your guess that are in the correct spot.")
    print("2. Cows represent digits in your guess that are not in the correct spot, but do appear in the password.")
    print("3. Entropy represents how close you are to cracking the code! An entropy of 0 means your guess exactly matches the password so lower is better.")
    print("oooooooooooooooooooooooooooooooooooooooooooooo\n")

    # Game loop
    continueGame = True

    while(continueGame):

        # Create game (it will automatically run)
        game = Game()

        # Determining whether to start another game
        invalidResponse = True

        while(invalidResponse):
            # Ask to play another game when done
            print("\nWould you like to start a new game?")
            response = input("Enter YES or NO: ").upper()
            print(f"You entered: {response}")
            
            # Stop program are continue based on response
            if response == "YES":
                print("New game starting ...\n")
                invalidResponse = False
            elif response == "NO":
                print("Hope you enjoyed the game! Goodbye!")
                invalidResponse = False
                continueGame = False
            else:
                print("INPUT ERROR: Please enter YES or NO.")


if __name__ == "__main__":
    main()